document.addEventListener("DOMContentLoaded", () => {

    // 1. Initialize Lenis Smooth Scroll
    const lenis = new Lenis({
        duration: 1.2,
        easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        direction: 'vertical',
        gestureDirection: 'vertical',
        smooth: true,
        mouseMultiplier: 1,
        smoothTouch: false,
        touchMultiplier: 2,
        infinite: false,
        lerp: 0.1
    });

    function raf(time) {
        lenis.raf(time);
        requestAnimationFrame(raf);
    }
    requestAnimationFrame(raf);

    gsap.registerPlugin(ScrollTrigger);
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add((time) => { lenis.raf(time * 1000); });
    gsap.ticker.lagSmoothing(0);

    // 2. Custom Cursor — only on devices with a precise pointer (desktop)
    const isPointerFine = window.matchMedia('(pointer: fine)').matches;

    if (isPointerFine) {
        const cursorDot  = document.getElementById('cursor-dot');
        const cursorRing = document.getElementById('cursor-ring');

        let mouseX = 0, mouseY = 0;
        let ringX  = 0, ringY  = 0;
        let smokeActive = false;

        window.addEventListener('mousemove', (e) => {
            mouseX = e.clientX;
            mouseY = e.clientY;
            cursorDot.style.left = `${mouseX}px`;
            cursorDot.style.top  = `${mouseY}px`;
            smokeActive = true;
            // Stop marking as active after 200ms of no movement
            clearTimeout(smokeActive._timer);
            smokeActive._timer = setTimeout(() => { smokeActive = false; }, 200);
        });

        gsap.ticker.add(() => {
            ringX += (mouseX - ringX) * 0.15;
            ringY += (mouseY - ringY) * 0.15;
            cursorRing.style.left = `${ringX}px`;
            cursorRing.style.top  = `${ringY}px`;
            drawSmoke();
        });

        // Magnetic Elements
        const magneticEls = document.querySelectorAll('.magnetic');
        magneticEls.forEach((el) => {
            el.addEventListener('mousemove', function(e) {
                const bound    = el.getBoundingClientRect();
                const strength = el.dataset.strength || 20;
                const px = (e.clientX - bound.left - (bound.width / 2))  / (bound.width / 2);
                const py = (e.clientY - bound.top  - (bound.height / 2)) / (bound.height / 2);
                gsap.to(el, { x: px * strength, y: py * strength, duration: 0.5, ease: "power2.out" });
                document.body.classList.add('cursor-hover');
            });
            el.addEventListener('mouseleave', function() {
                gsap.to(el, { x: 0, y: 0, duration: 0.5, ease: "power2.out" });
                document.body.classList.remove('cursor-hover');
            });
        });

        const hoverEls = document.querySelectorAll('a, button, .bento-item');
        hoverEls.forEach(el => {
            if (!el.classList.contains('magnetic')) {
                el.addEventListener('mouseenter', () => document.body.classList.add('cursor-hover'));
                el.addEventListener('mouseleave', () => document.body.classList.remove('cursor-hover'));
            }
        });

        // Smoke Canvas — only runs when mouse is moving or particles remain
        const canvas = document.getElementById('smoke-canvas');
        const ctx    = canvas.getContext('2d');
        canvas.width  = window.innerWidth;
        canvas.height = window.innerHeight;

        window.addEventListener('resize', () => {
            canvas.width  = window.innerWidth;
            canvas.height = window.innerHeight;
        });

        let particles = [];

        function createParticle() {
            if (Math.random() > 0.4) {
                particles.push({
                    x: mouseX,
                    y: mouseY,
                    size:    Math.random() * 8 + 2,
                    vx:      (Math.random() - 0.5) * 1.5,
                    vy:      (Math.random() - 0.5) * 1.5 - 0.5,
                    opacity: 0.15
                });
            }
        }

        function drawSmoke() {
            // Skip expensive canvas work when cursor isn't moving and no particles remain
            if (!smokeActive && particles.length === 0) {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                return;
            }

            ctx.clearRect(0, 0, canvas.width, canvas.height);

            if (smokeActive) createParticle();

            for (let i = 0; i < particles.length; i++) {
                let p = particles[i];
                p.x += p.vx;
                p.y += p.vy;
                p.size    += 0.1;
                p.opacity -= 0.003;

                if (p.opacity <= 0) {
                    particles.splice(i, 1);
                    i--;
                    continue;
                }

                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(150, 150, 150, ${p.opacity})`;
                ctx.fill();
            }
        }
    }

    // 3. Hero Animations
    const heroTl = gsap.timeline();
    heroTl
        .to(".hero-title", {
            y: 0, opacity: 1, duration: 1.2, ease: "power4.out", delay: 0.4
        })
        .to(".hero-subtitle", {
            y: 0, opacity: 1, duration: 1, ease: "power3.out"
        }, "-=0.8")
        .to(".hero-desc", {
            opacity: 1, duration: 1, y: -10, ease: "power2.out"
        }, "-=0.6")
        .fromTo(".btn-primary", { opacity: 0, y: 20 }, {
            opacity: 1, y: 0, duration: 0.8, ease: "power2.out"
        }, "-=0.4");

    // 4. Horizontal Scroll — Services
    const servicesSection   = document.querySelector('.services');
    const servicesContainer = document.querySelector('.services-container');
    const serviceCards      = gsap.utils.toArray('.service-card');

    // Only apply horizontal scroll on non-mobile screens
    const isMobile = window.innerWidth < 768;

    if (!isMobile) {
        let scrollWidth = servicesContainer.scrollWidth - window.innerWidth;

        gsap.to(servicesContainer, {
            x: () => -(servicesContainer.scrollWidth - window.innerWidth) - 100,
            ease: "none",
            scrollTrigger: {
                trigger: servicesSection,
                pin: true,
                scrub: 1,
                start: "top top",
                end: () => `+=${servicesContainer.scrollWidth - window.innerWidth + window.innerWidth}`,
                invalidateOnRefresh: true,
                onUpdate: (self) => {
                    const progress    = self.progress;
                    const totalCards  = serviceCards.length;
                    const activeIndex = Math.min(Math.floor(progress * totalCards * 1.5), totalCards - 1);
                    serviceCards.forEach((card, index) => {
                        card.classList.toggle('active', index === activeIndex);
                    });
                }
            }
        });

        setTimeout(() => { serviceCards[0].classList.add('active'); }, 500);

    } else {
        // Mobile: show all cards stacked, all active
        serviceCards.forEach(card => card.classList.add('active'));
    }

    // 5. Image Parallax — Gallery
    const bentoItems = gsap.utils.toArray('.img-parallax img, .img-parallax video');
    bentoItems.forEach(item => {
        gsap.to(item, {
            y: "10%",
            ease: "none",
            scrollTrigger: {
                trigger: item.parentNode,
                start: "top bottom",
                end: "bottom top",
                scrub: true
            }
        });
    });

    // 6. Footer Logo Scale
    const footerLogo = document.querySelector('.logo-scale');
    if (footerLogo) {
        gsap.fromTo(footerLogo,
            { scale: 0.5, opacity: 0.02 },
            {
                scale: 1.15,
                opacity: 0.06,
                ease: "none",
                scrollTrigger: {
                    trigger: ".mega-footer",
                    start: "top bottom",
                    end: "bottom bottom",
                    scrub: true
                }
            }
        );
    }

    // 7. Scroll-triggered fade-in for footer sections
    gsap.fromTo(".footer-grid",
        { opacity: 0, y: 40 },
        {
            opacity: 1, y: 0, duration: 1, ease: "power3.out",
            scrollTrigger: { trigger: ".footer-grid", start: "top 85%" }
        }
    );

});
